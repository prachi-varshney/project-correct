<nav id="sidebar" class="sidebar" class="active">

  <center>
    <h1><img src="sansoftlogo.png" width="70%" height="80%"></h1>
  </center>
  <ul class="list-unstyled components mb-5">
    <li class="active">
      <a href="#"><span class="fa fa-home"></span> Dashboard</a>
    </li>
    <li>
      <a href="usermaster.php"><span class="fa fa-user" style="transition: 0.5s;"></span> User Master</a>
    </li>
    <li>
      <a href="clientmaster.php"><span class="fa-solid fa-users-gear"></span> Client Master</a>
    </li>
    <li>
      <a href="itemmaster.php"><span class="fa fa-cogs"></span> Item Master</a>
    </li>
    <li>
      <a href="invoice.php"><span class="fa-solid fa-file-invoice"></span> Invoice</a>
    </li>
    <li>
      <a href="logout.php"><span class="fa fa-arrow-left"></span> LogOut</a>
    </li>
  </ul>
</nav>